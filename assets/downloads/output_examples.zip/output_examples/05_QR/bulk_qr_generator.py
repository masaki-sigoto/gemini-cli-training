#!/usr/bin/env python3
"""
複数URLを一括でQRコード画像化するスクリプト

【使い方】
1. urls.csv を以下の形式で作成（用途, URL, ファイル名 の3列）
     用途,URL,ファイル名
     セミナー告知,https://example.com/seminar,qr_seminar.png
     申込フォーム,https://example.com/apply,qr_apply.png

2. このスクリプトと同じフォルダに urls.csv を置く

3. 実行:
     Mac:     python3 bulk_qr_generator.py
     Windows: python bulk_qr_generator.py

4. qr_codes/ フォルダに PNG が一括生成される
5. result_summary.csv に成功/失敗の一覧が出力される

【出力】
- qr_codes/qr_*.png         ... 各URLのQRコード画像（300x300px）
- qr_codes/result_summary.csv ... 成功/失敗の一覧
- 標準出力: 進捗ログ

【必要なライブラリ】
pip3 install qrcode Pillow
"""
import csv
import sys
from pathlib import Path

try:
    import qrcode
except ImportError:
    print("❌ qrcode ライブラリが必要です。以下を実行してください:")
    print("   pip3 install qrcode Pillow")
    sys.exit(1)


def generate_qr(url: str, output_path: Path, *, box_size: int = 10, border: int = 4) -> bool:
    """QRコード画像を生成して保存。成功時 True、失敗時 False。"""
    try:
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,  # 30%復元可能
            box_size=box_size,
            border=border,
        )
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(output_path)
        return True
    except Exception as e:
        print(f"   ⚠️ 失敗: {e}")
        return False


def main():
    script_dir = Path(__file__).parent
    input_csv = script_dir / "urls.csv"
    output_dir = script_dir / "qr_codes"
    summary_csv = output_dir / "result_summary.csv"

    if not input_csv.exists():
        print(f"❌ {input_csv.name} が見つかりません。")
        print(f"   以下の形式で urls.csv を作成してください:")
        print(f"   用途,URL,ファイル名")
        print(f"   セミナー告知,https://example.com/seminar,qr_seminar.png")
        sys.exit(1)

    output_dir.mkdir(exist_ok=True)
    results = []

    with open(input_csv, encoding="utf-8") as f:
        reader = csv.reader(f)
        rows = list(reader)

    if not rows:
        print("❌ urls.csv が空です。")
        sys.exit(1)

    # ヘッダーをスキップするか判定
    header = rows[0]
    if "URL" in header or "url" in header:
        data_rows = rows[1:]
    else:
        data_rows = rows

    print(f"📋 {len(data_rows)} 件の URL を処理します")
    print()

    for i, row in enumerate(data_rows, 1):
        if len(row) < 3:
            print(f"⚠️ {i}件目: 列数が足りません（用途,URL,ファイル名 の3列必須）")
            results.append((row[0] if row else "", "", "", "失敗（列不足）"))
            continue
        use, url, filename = row[0], row[1], row[2]
        print(f"[{i}/{len(data_rows)}] {use}: {url}")
        output_path = output_dir / filename
        success = generate_qr(url, output_path)
        status = "✓ 成功" if success else "✗ 失敗"
        print(f"   → {filename}  {status}")
        results.append((use, url, filename, status))

    # 結果サマリを書き出す
    with open(summary_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["用途", "URL", "ファイル名", "結果"])
        writer.writerows(results)

    success_count = sum(1 for r in results if "成功" in r[3])
    fail_count = len(results) - success_count

    print()
    print("=" * 50)
    print(f"✅ 完了: 成功 {success_count} 件 / 失敗 {fail_count} 件")
    print(f"   出力先: {output_dir}")
    print(f"   サマリ: {summary_csv.name}")
    print("=" * 50)

    if fail_count > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
